// Motion detection utilities for smart frame selection

export interface FrameInfo {
  timestamp: number;
  dataUrl: string;
  motionScore: number;
  isKeyFrame: boolean;
}

// Calculate motion between two frames
function calculateMotion(
  imageData1: ImageData,
  imageData2: ImageData
): number {
  const data1 = imageData1.data;
  const data2 = imageData2.data;
  let totalDiff = 0;
  let pixelCount = 0;

  // Sample every 4th pixel for performance
  for (let i = 0; i < data1.length; i += 16) {
    const r1 = data1[i];
    const g1 = data1[i + 1];
    const b1 = data1[i + 2];

    const r2 = data2[i];
    const g2 = data2[i + 1];
    const b2 = data2[i + 2];

    const diff = Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
    totalDiff += diff;
    pixelCount++;
  }

  return totalDiff / pixelCount / 255; // Normalize to 0-3
}

// Extract frames with motion detection
export async function extractFramesWithMotion(
  source: File | string,
  targetFrameCount = 28
): Promise<FrameInfo[]> {
  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.crossOrigin = "anonymous";
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";

    const cleanup = () => {
      if (typeof source !== "string") URL.revokeObjectURL(video.src);
    };

    video.onerror = () => {
      cleanup();
      reject(
        new Error(
          "Could not load video. If using a URL, it must be a direct video link with CORS enabled."
        )
      );
    };

    video.onloadedmetadata = async () => {
      const duration = video.duration;
      if (!isFinite(duration) || duration <= 0) {
        cleanup();
        reject(new Error("Invalid video duration"));
        return;
      }

      const canvas = document.createElement("canvas");
      const w = (canvas.width = Math.min(768, video.videoWidth || 768));
      const h = (canvas.height = Math.round(
        w * ((video.videoHeight || 512) / (video.videoWidth || 512))
      ));
      const ctx = canvas.getContext("2d", { willReadFrequently: true })!;

      // First pass: sample many frames at fine resolution to find the action burst
      const samplingCount = Math.min(96, Math.max(48, Math.round(duration * 12))); // ~12 fps cap
      const allFrames: FrameInfo[] = [];
      let previousImageData: ImageData | null = null;

      for (let i = 1; i <= samplingCount; i++) {
        const t = (duration * i) / (samplingCount + 1);

        await new Promise<void>((res, rej) => {
          const onSeeked = () => {
            video.removeEventListener("seeked", onSeeked);
            try {
              ctx.drawImage(video, 0, 0, w, h);
              const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
              const currentImageData = ctx.getImageData(0, 0, w, h);

              let motionScore = 0;
              if (previousImageData) {
                motionScore = calculateMotion(previousImageData, currentImageData);
              }

              allFrames.push({
                timestamp: t,
                dataUrl,
                motionScore,
                isKeyFrame: false,
              });

              previousImageData = currentImageData;
              res();
            } catch (e) {
              rej(e);
            }
          };
          video.addEventListener("seeked", onSeeked);
          video.currentTime = t;
        });
      }

      // Identify the highest-motion BURST (contiguous window) and densely sample it.
      // A skill (flip) is a contiguous burst of motion. We want dense coverage of that
      // burst plus some context before/after for takeoff/landing.
      const motionScores = allFrames.map((f) => f.motionScore);
      const maxMotion = Math.max(...motionScores);
      const meanMotion =
        motionScores.reduce((a, b) => a + b, 0) / motionScores.length;
      // Threshold = mean + 30% of (max - mean): catches the burst
      const burstThreshold = meanMotion + (maxMotion - meanMotion) * 0.3;

      // Mark frames in the burst (extend by 2 frames each side for context)
      const inBurst: boolean[] = motionScores.map((m) => m >= burstThreshold);
      for (let i = 0; i < inBurst.length; i++) {
        if (inBurst[i]) {
          for (let j = Math.max(0, i - 2); j <= Math.min(inBurst.length - 1, i + 2); j++) {
            allFrames[j].isKeyFrame = true;
          }
        }
      }

      const burstFrames = allFrames.filter((f) => f.isKeyFrame);
      const otherFrames = allFrames.filter((f) => !f.isKeyFrame);

      // Allocate ~70% of budget to the burst (high-motion = flip happens here),
      // 30% evenly across the rest for context.
      const burstBudget = Math.min(
        burstFrames.length,
        Math.floor(targetFrameCount * 0.7)
      );
      const contextBudget = targetFrameCount - burstBudget;

      // Densely sample burst (evenly across burst frames if too many)
      const burstStep = Math.max(1, Math.floor(burstFrames.length / burstBudget));
      const selectedBurst: FrameInfo[] = [];
      for (let i = 0; i < burstFrames.length && selectedBurst.length < burstBudget; i += burstStep) {
        selectedBurst.push(burstFrames[i]);
      }

      // Evenly distribute context frames
      const contextStep = Math.max(1, Math.floor(otherFrames.length / Math.max(1, contextBudget)));
      const selectedContext: FrameInfo[] = [];
      for (
        let i = 0;
        i < otherFrames.length && selectedContext.length < contextBudget;
        i += contextStep
      ) {
        selectedContext.push(otherFrames[i]);
      }

      // Combine and sort by timestamp
      const selectedFrames = [...selectedBurst, ...selectedContext].sort(
        (a, b) => a.timestamp - b.timestamp
      );

      cleanup();
      resolve(selectedFrames.slice(0, targetFrameCount));
    };

    video.src = typeof source === "string" ? source : URL.createObjectURL(source);
  });
}

// Extract regular frames (fallback method)
export async function extractFramesRegular(
  source: File | string,
  count = 28
): Promise<FrameInfo[]> {
  return new Promise((resolve, reject) => {
    const video = document.createElement("video");
    video.crossOrigin = "anonymous";
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";

    const cleanup = () => {
      if (typeof source !== "string") URL.revokeObjectURL(video.src);
    };

    video.onerror = () => {
      cleanup();
      reject(
        new Error(
          "Could not load video. If using a URL, it must be a direct video link with CORS enabled."
        )
      );
    };

    video.onloadedmetadata = async () => {
      const duration = video.duration;
      if (!isFinite(duration) || duration <= 0) {
        cleanup();
        reject(new Error("Invalid video duration"));
        return;
      }

      const canvas = document.createElement("canvas");
      const w = (canvas.width = Math.min(768, video.videoWidth || 768));
      const h = (canvas.height = Math.round(
        w * ((video.videoHeight || 512) / (video.videoWidth || 512))
      ));
      const ctx = canvas.getContext("2d")!;
      const frames: FrameInfo[] = [];

      for (let i = 1; i <= count; i++) {
        const t = (duration * i) / (count + 1);
        await new Promise<void>((res, rej) => {
          const onSeeked = () => {
            video.removeEventListener("seeked", onSeeked);
            try {
              ctx.drawImage(video, 0, 0, w, h);
              frames.push({
                timestamp: t,
                dataUrl: canvas.toDataURL("image/jpeg", 0.92),
                motionScore: 0,
                isKeyFrame: false,
              });
              res();
            } catch (e) {
              rej(e);
            }
          };
          video.addEventListener("seeked", onSeeked);
          video.currentTime = t;
        });
      }

      cleanup();
      resolve(frames);
    };

    video.src = typeof source === "string" ? source : URL.createObjectURL(source);
  });
}
