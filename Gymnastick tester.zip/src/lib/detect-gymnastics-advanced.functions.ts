import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SegmentSchema = z.object({
  startFrame: z.number(),
  endFrame: z.number(),
  peakFrame: z.number(),
  durationSec: z.number(),
  somersaultCount: z.number(),
  direction: z.enum(["back", "front", "side", "unknown"]),
  maxBodyAngle: z.number(),
  estimatedTwists: z.number(),
  shape: z.enum(["tuck", "pike", "layout", "unknown"]),
  estimatedName: z.string(),
});

const InputSchema = z.object({
  frames: z.array(z.string().startsWith("data:image/")).min(1).max(60),
  poseData: z.array(z.object({
    hasPose: z.boolean(),
    flipAnalysis: z.object({
      isInverted: z.boolean(),
      bodyAngle: z.number(),
      rotationSpeed: z.number(),
      confidence: z.number(),
      phase: z.enum(["takeoff", "rotation", "landing", "none"]),
    }).optional(),
    timestamp: z.number(),
  })).optional(),
  skillSegments: z.array(SegmentSchema).optional(),
});

type SegmentInput = z.infer<typeof SegmentSchema>;


export type TrickDetection = {
  name: string;
  confidence: number;
  description: string;
  frameIndices: number[];
  trickType: string;
  rotationDegrees?: number;
  twistDegrees?: number;
  difficulty?: string;
};

export type EnhancedVerdict = {
  isGymnastics: boolean;
  confidence: number;
  disciplines: string[];
  tricks: TrickDetection[];
  hasTrick: boolean;
  reasoning: string;
  analysisError?: string;
  poseDetectionSummary: string;
  frameBreakdown: Array<{
    frameIndex: number;
    timestamp: number;
    hasPose: boolean;
    phase: string;
    bodyAngle: number;
    confidence: number;
  }>;
};

export const detectGymnasticsAdvanced = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<EnhancedVerdict> => {
    const buildFrameBreakdown = () => (data.poseData || []).map((p, i) => ({
      frameIndex: i + 1,
      timestamp: p.timestamp,
      hasPose: p.hasPose,
      phase: p.flipAnalysis?.phase || "none",
      bodyAngle: p.flipAnalysis?.bodyAngle || 0,
      confidence: p.flipAnalysis?.confidence || 0,
    }));

    const apiKey = process.env.LOVABLE_API_KEY || process.env.OPENAI_API_KEY || process.env.EMERGENT_LLM_KEY;
    const useLovable = Boolean(process.env.LOVABLE_API_KEY);
    const endpoint = useLovable
      ? "https://ai.gateway.lovable.dev/v1/chat/completions"
      : "https://api.openai.com/v1/chat/completions";
    const model = useLovable ? "google/gemini-2.5-flash" : "gpt-4o";

    // Prepare pose detection summary
    const poseFrames = data.poseData || [];
    const framesWithFlips = poseFrames.filter(
      (p) => p.flipAnalysis && (p.flipAnalysis.phase === "rotation" || p.flipAnalysis.phase === "takeoff")
    );

    const poseDetectionSummary = poseFrames.length > 0
      ? `Pose detection analyzed ${poseFrames.length} frames. Found ${framesWithFlips.length} frames with potential flip motion. ` +
        `Detected phases: ${poseFrames
          .filter((p) => p.flipAnalysis?.phase !== "none")
          .map((p, i) => `Frame ${i + 1}: ${p.flipAnalysis?.phase} (${Math.round(p.flipAnalysis?.bodyAngle || 0)}°)`)
          .join(", ") || "none"}`
      : "No pose detection data available.";

    const buildFallbackVerdict = (reasoning: string, analysisError?: string): EnhancedVerdict => ({
      isGymnastics: false,
      confidence: 0,
      disciplines: [],
      tricks: [],
      hasTrick: false,
      reasoning,
      analysisError,
      poseDetectionSummary,
      frameBreakdown: buildFrameBreakdown(),
    });

    if (!apiKey) {
      return buildFallbackVerdict(
        "Pose analysis completed, but GPT-4o vision analysis could not run because the OpenAI API key is not configured.",
        "OPENAI_API_KEY is not configured"
      );
    }

    const segments: SegmentInput[] = data.skillSegments || [];
    const segmentSummary = segments.length > 0
      ? segments
          .map(
            (s, i) =>
              `Segment ${i + 1}: frames ${s.startFrame}-${s.endFrame} (peak ${s.peakFrame}), ` +
              `~${s.somersaultCount} ${s.direction} somersault(s), ~${s.estimatedTwists} twist(s), ` +
              `shape=${s.shape}, peak body angle=${s.maxBodyAngle}°, duration=${s.durationSec.toFixed(2)}s — ` +
              `preliminary guess: "${s.estimatedName}"`
          )
          .join("\n")
      : "No discrete airborne segments isolated by pose analysis.";

    // Create enhanced system prompt with pose data
    const systemPrompt = `You are an elite gymnastics and acrobatics analyst with expertise in biomechanics. You will analyze video frames in strict chronological order along with pose detection data.

POSE DETECTION CONTEXT:
${poseDetectionSummary}

Frames with detected rotation phases: ${framesWithFlips.map((_, i) => i + 1).join(", ") || "none"}

PRE-COMPUTED SKILL SEGMENTS (each segment = ONE discrete airborne skill, takeoff → landing):
${segmentSummary}

CRITICAL ANALYSIS RULES:

1. **One trick PER segment — CHAIN DETECTION IS MANDATORY:**
   - The skill segments above were computed from pose biomechanics and represent
     INDEPENDENT airborne phases. Each segment is ONE distinct skill.
   - You MUST output AT LEAST one trick entry for EACH segment listed above
     (length of "tricks" array >= number of segments). Do NOT merge two
     segments into one trick. A round-off + back handspring + back tuck is
     THREE tricks, not one. If frames between segments show hand contact
     with the ground (handspring, round-off, cartwheel), that is ALSO a
     skill and gets its own trick entry.
   - If a segment's preliminary name looks wrong from the frames, correct
     it — but keep the same frame range and still emit one trick for it.

2. **Trick Classification Vocabulary:**
   - **Backflip/Back Somersault:** backward rotation, variants: back tuck, back pike, back layout
   - **Frontflip/Front Somersault:** forward rotation, variants: front tuck, front pike, front layout
   - **Aerial/Side Flip:** lateral rotation without hands
   - **Cartwheel/Round-off:** lateral with hand support
   - **Handspring:** forward/back with hand support (front handspring, back handspring)
   - **Twists:** Add "full twist", "half twist", "double twist" if spinning on vertical axis
   - **Double/Triple:** Multiple rotations (double back, triple front)
   - **Combinations:** e.g., "back full" (backflip with full twist)

3. **Frame-by-Frame Evidence:**
   - For EACH trick, cite the specific frame numbers (1-based) showing it.
   - Order tricks chronologically by their first frame.

4. **Difficulty Assessment:** basic | intermediate | advanced | elite.

5. **Gymnastics vs Other Sports:** artistic, rhythmic, trampoline, tumbling,
   acro count as gymnastics. Tricking/parkour DO contain gymnastics-like
   tricks — still list each trick.

Return ONLY valid JSON matching this structure:
{
  "isGymnastics": boolean,
  "confidence": number (0-1),
  "disciplines": string[],
  "hasTrick": boolean,
  "tricks": [
    {
      "name": "specific trick name",
      "confidence": number (0-1),
      "description": "cite frame numbers and what you see",
      "frameIndices": number[],
      "trickType": "flip|somersault|aerial|twist|handspring|cartwheel|roundoff|combination",
      "rotationDegrees": number,
      "difficulty": "basic|intermediate|advanced|elite"
    }
  ],
  "reasoning": "one sentence summary citing segment count + visual evidence"
}`;

    const userContent: Array<
      { type: "text"; text: string } | { type: "image_url"; image_url: { url: string } }
    > = [
      {
        type: "text",
        text: `Analyze these ${data.frames.length} frames (chronological order).

POSE DETECTION RESULTS:
${poseFrames
  .map(
    (p, i) =>
      `Frame ${i + 1} (${p.timestamp.toFixed(2)}s): ${p.hasPose ? `pose ok, phase=${p.flipAnalysis?.phase || "none"}, bodyAngle=${Math.round(p.flipAnalysis?.bodyAngle || 0)}°` : "no pose"}`
  )
  .join("\n")}

PRE-COMPUTED SKILL SEGMENTS: ${segments.length} segment(s) detected.
${segmentSummary}

You MUST return at least ${segments.length} trick(s). Identify EACH skill in the chain separately, in chronological order.`,
      },
      ...data.frames.map((f) => ({ type: "image_url" as const, image_url: { url: f } })),
    ];


    const requestBody: Record<string, unknown> = {
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent },
      ],
      max_tokens: 2000,
    };
    // Gemini via Lovable Gateway doesn't accept response_format json_object; only enforce for OpenAI.
    if (!useLovable) {
      requestBody.response_format = { type: "json_object" };
    }

    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify(requestBody),
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) {
        return buildFallbackVerdict("Pose analysis completed, but GPT-4o is rate limited right now. Please try again shortly.", "Rate limit reached");
      }
      if (res.status === 401) {
        return buildFallbackVerdict(
          "Pose analysis completed, but GPT-4o vision analysis could not authenticate with the configured OpenAI API key.",
          "OpenAI API authentication failed. The OPENAI_API_KEY secret is missing or invalid."
        );
      }
      return buildFallbackVerdict(
        "Pose analysis completed, but GPT-4o vision analysis failed before returning a result.",
        `OpenAI API error (${res.status}): ${text}`
      );
    }

    const json = (await res.json()) as {
      choices: Array<{ message: { content: string } }>;
    };

    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: Partial<EnhancedVerdict>;

    const extractJson = (s: string): string => {
      const fenced = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
      const candidate = fenced ? fenced[1] : s;
      const start = candidate.indexOf("{");
      const end = candidate.lastIndexOf("}");
      return start !== -1 && end !== -1 ? candidate.slice(start, end + 1) : candidate;
    };

    try {
      parsed = JSON.parse(extractJson(raw)) as Partial<EnhancedVerdict>;
    } catch {
      console.error("AI non-JSON response:", raw.slice(0, 500));
      return buildFallbackVerdict("Pose analysis completed, but the AI returned an unreadable response.", "AI returned non-JSON response");
    }


    const tricks: TrickDetection[] = Array.isArray(parsed.tricks)
      ? parsed.tricks
          .filter((t): t is TrickDetection => Boolean(t && typeof t.name === "string"))
          .map((t) => ({
            name: t.name,
            confidence: typeof t.confidence === "number" ? t.confidence : 0,
            description: typeof t.description === "string" ? t.description : "",
            frameIndices: Array.isArray(t.frameIndices) ? t.frameIndices : [],
            trickType: typeof t.trickType === "string" ? t.trickType : "unknown",
            rotationDegrees: typeof t.rotationDegrees === "number" ? t.rotationDegrees : undefined,
            difficulty: typeof t.difficulty === "string" ? t.difficulty : undefined,
          }))
      : [];

    // Backfill: if AI returned fewer tricks than locally-detected airborne segments,
    // add the missing ones from segmentation so chains are never under-counted.
    const overlaps = (a: number[], start: number, end: number) =>
      a.some((n) => n >= start - 1 && n <= end + 1);
    for (const seg of segments) {
      const covered = tricks.some((t) => overlaps(t.frameIndices, seg.startFrame, seg.endFrame));
      if (!covered) {
        tricks.push({
          name: seg.estimatedName,
          confidence: 0.55,
          description: `Pose-segmentation skill (frames ${seg.startFrame}–${seg.endFrame}, peak ${seg.peakFrame}): ${seg.somersaultCount} ${seg.direction} rotation(s), ${seg.estimatedTwists} twist(s), shape ${seg.shape}. Added from local biomechanics because the vision model did not list this segment.`,
          frameIndices: [seg.startFrame, seg.peakFrame, seg.endFrame],
          trickType: seg.estimatedTwists >= 0.5 ? "twist" : "flip",
          rotationDegrees: Math.round(seg.somersaultCount * 360),
          difficulty:
            seg.somersaultCount >= 3 ? "elite"
            : seg.somersaultCount >= 2 ? "advanced"
            : seg.somersaultCount >= 1 ? "intermediate"
            : "basic",
        });
      }
    }
    // Sort chronologically by first frame.
    tricks.sort((a, b) => (a.frameIndices[0] || 0) - (b.frameIndices[0] || 0));


    return {
      isGymnastics: Boolean(parsed.isGymnastics),
      confidence: typeof parsed.confidence === "number" ? parsed.confidence : 0,
      disciplines: Array.isArray(parsed.disciplines) ? parsed.disciplines : [],
      hasTrick: typeof parsed.hasTrick === "boolean" ? parsed.hasTrick : tricks.length > 0,
      tricks,
      reasoning: typeof parsed.reasoning === "string" ? parsed.reasoning : "",
      poseDetectionSummary,
      frameBreakdown: buildFrameBreakdown(),
    };
  });
