// Skill segmentation: groups consecutive airborne frames into individual skills
// (takeoff → rotation → landing = ONE skill), counts somersaults and estimates twists,
// and identifies chained skills.

import type { FlipAnalysis } from "./pose-detection";

export interface FrameAnalysisInput {
  frameIndex: number; // 1-based
  timestamp: number;
  hasPose: boolean;
  flip: FlipAnalysis;
}

export interface SkillSegment {
  startFrame: number; // 1-based
  endFrame: number; // 1-based
  peakFrame: number; // frame with highest body angle (most inverted)
  startTime: number;
  endTime: number;
  durationSec: number;
  totalRotationDeg: number; // absolute cumulative rotation across the segment
  signedRotationDeg: number; // signed (negative = backward, positive = forward)
  somersaultCount: number; // |signedRotationDeg| / 360 rounded to 0.25
  direction: "back" | "front" | "side" | "unknown";
  maxBodyAngle: number; // peak inversion angle
  estimatedTwists: number; // rough estimate from shoulder-width oscillation
  hasInversion: boolean; // any frame showing the athlete inverted
  shape: "tuck" | "pike" | "layout" | "unknown"; // rough body-shape estimate
  frameIndices: number[]; // all frame indices in this segment
  poseConfidence: number; // average pose confidence in segment
  estimatedName: string; // e.g., "Triple Back Tuck" — preliminary
}

// Decide whether a frame should be considered "airborne / in a skill"
function isAirborneFrame(f: FlipAnalysis): boolean {
  if (!f) return false;
  if (f.phase === "rotation") return true;
  if (f.isInverted) return true;
  if (f.feetAboveShoulders) return true;
  // Strong takeoff/landing rotation with feet up
  if (f.feetAboveHips && f.bodyAngle > 35) return true;
  if (f.rotationSpeed > 25 && f.bodyAngle > 30) return true;
  return false;
}

// Round to nearest 0.25 (so 1.95 → 2.0, 2.1 → 2.0, 2.4 → 2.5)
function roundQuarter(n: number): number {
  return Math.round(n * 4) / 4;
}

// Pretty-print rotation count (1 → "Single", 2 → "Double", 3 → "Triple", 4+ → "Quadruple")
function rotationWord(n: number): string {
  const r = Math.round(n);
  if (r <= 1) return "Single";
  if (r === 2) return "Double";
  if (r === 3) return "Triple";
  if (r === 4) return "Quadruple";
  if (r >= 5) return `${r}x`;
  return "Single";
}

function buildEstimatedName(seg: Omit<SkillSegment, "estimatedName">): string {
  // No real rotation? Could be a jump or partial trick
  if (seg.somersaultCount < 0.5) {
    if (seg.maxBodyAngle > 120) {
      return "Partial Flip";
    }
    return "Jump (no full rotation)";
  }

  const dir =
    seg.direction === "back"
      ? "Back"
      : seg.direction === "front"
        ? "Front"
        : seg.direction === "side"
          ? "Side"
          : "";

  const rot = rotationWord(seg.somersaultCount);
  const shape = seg.shape !== "unknown" ? ` ${seg.shape.charAt(0).toUpperCase() + seg.shape.slice(1)}` : "";

  let twistPart = "";
  if (seg.estimatedTwists >= 0.5) {
    const tHalves = Math.round(seg.estimatedTwists * 2) / 2; // halves
    if (tHalves === 0.5) twistPart = " with Half Twist";
    else if (tHalves === 1) twistPart = " with Full Twist";
    else if (tHalves === 1.5) twistPart = " with 1.5 Twist";
    else twistPart = ` with ${tHalves}x Twist`;
  }

  // "Single" sounds redundant for plain singles, so omit it.
  const rotLabel = rot === "Single" ? "" : `${rot} `;
  return `${rotLabel}${dir} Flip${shape}${twistPart}`.trim();
}

function estimateShape(maxRotationSpeed: number, avgBodyAngleDuringInversion: number): "tuck" | "pike" | "layout" | "unknown" {
  // High rotation speed → tighter shape (tuck). Lower → layout/pike.
  if (maxRotationSpeed > 120) return "tuck";
  if (maxRotationSpeed > 80) return "pike";
  if (maxRotationSpeed > 0 && avgBodyAngleDuringInversion > 100) return "layout";
  return "unknown";
}

// Estimate twists by counting peaks/valleys in shoulder-width during the segment.
// When the body twists ~90°, shoulders appear narrow; ~180° they appear wide again.
// Two narrow-points → one full twist (approximately).
function estimateTwists(shoulderWidths: number[]): number {
  if (shoulderWidths.length < 4) return 0;
  const max = Math.max(...shoulderWidths);
  const min = Math.min(...shoulderWidths);
  const range = max - min;
  // Need meaningful variation
  if (range < 0.05) return 0;
  const mid = (max + min) / 2;
  // Count crossings of the midline (each twist = 2 crossings)
  let crossings = 0;
  for (let i = 1; i < shoulderWidths.length; i++) {
    const prev = shoulderWidths[i - 1];
    const cur = shoulderWidths[i];
    if ((prev < mid && cur >= mid) || (prev >= mid && cur < mid)) {
      crossings++;
    }
  }
  // Rough estimate: 2 crossings per half-twist
  return crossings / 4;
}

/**
 * Segment frames into individual skills. Each segment = one skill (takeoff to landing).
 * Multiple segments in a video = chained skills (e.g., round-off + back handspring + triple back).
 */
export function segmentSkills(frames: FrameAnalysisInput[]): SkillSegment[] {
  if (frames.length === 0) return [];

  // Identify candidate airborne flags
  const airborneFlags = frames.map((f) => f.hasPose && isAirborneFrame(f.flip));

  // Smooth: fill single-frame gaps (true,false,true → true,true,true)
  for (let i = 1; i < airborneFlags.length - 1; i++) {
    if (!airborneFlags[i] && airborneFlags[i - 1] && airborneFlags[i + 1]) {
      airborneFlags[i] = true;
    }
  }

  // Collect contiguous airborne runs
  const segments: SkillSegment[] = [];
  let runStart = -1;
  for (let i = 0; i <= airborneFlags.length; i++) {
    const isAir = i < airborneFlags.length && airborneFlags[i];
    if (isAir && runStart < 0) {
      runStart = i;
    } else if (!isAir && runStart >= 0) {
      const runEnd = i - 1;
      const segFrames = frames.slice(runStart, runEnd + 1);

      // Need at least 2 airborne frames to be a meaningful skill
      if (segFrames.length >= 1) {
        const seg = buildSegment(segFrames, frames);
        if (seg) segments.push(seg);
      }
      runStart = -1;
    }
  }

  return segments;
}

function buildSegment(
  segFrames: FrameAnalysisInput[],
  allFrames: FrameAnalysisInput[]
): SkillSegment | null {
  if (segFrames.length === 0) return null;

  // Compute signed cumulative rotation by summing wrapped deltas.
  // We use the signedBodyAngle from one frame to the next.
  let signedRot = 0;
  let totalAbsRot = 0;
  const widths: number[] = [];
  let peakFrame = segFrames[0];
  let maxBodyAngle = 0;
  let maxRotSpeed = 0;
  let confSum = 0;
  let invertedAngleSum = 0;
  let invertedCount = 0;

  // Include one frame before for delta context (helps with takeoff direction)
  const firstIdx = allFrames.indexOf(segFrames[0]);
  const startContextIdx = Math.max(0, firstIdx - 1);
  const seqWithContext = allFrames.slice(startContextIdx, firstIdx + segFrames.length);

  for (let i = 0; i < seqWithContext.length; i++) {
    const cur = seqWithContext[i];
    if (i > 0) {
      const prev = seqWithContext[i - 1];
      if (cur.hasPose && prev.hasPose) {
        let delta = cur.flip.signedBodyAngle - prev.flip.signedBodyAngle;
        if (delta > 180) delta -= 360;
        if (delta < -180) delta += 360;
        // Only count rotation when actually rotating fast enough (filters jitter)
        if (Math.abs(delta) > 3) {
          signedRot += delta;
          totalAbsRot += Math.abs(delta);
        }
      }
    }
  }

  for (const f of segFrames) {
    if (!f.hasPose) continue;
    widths.push(f.flip.shoulderWidth);
    confSum += f.flip.confidence;
    if (f.flip.bodyAngle > maxBodyAngle) {
      maxBodyAngle = f.flip.bodyAngle;
      peakFrame = f;
    }
    if (f.flip.rotationSpeed > maxRotSpeed) maxRotSpeed = f.flip.rotationSpeed;
    if (f.flip.bodyAngle > 90) {
      invertedAngleSum += f.flip.bodyAngle;
      invertedCount++;
    }
  }

  const hasInversion = segFrames.some((f) => f.hasPose && f.flip.isInverted);
  const avgInvAngle = invertedCount > 0 ? invertedAngleSum / invertedCount : 0;

  // Direction: sign of signed rotation tells us back vs front.
  // In our coord convention (image y is down), positive signedRot ≈ forward rotation
  // (athlete rotating forward over the camera-left side). To be safe, we use
  // a heuristic based on the sign and peak body orientation.
  let direction: SkillSegment["direction"] = "unknown";
  if (Math.abs(signedRot) > 90) {
    direction = signedRot < 0 ? "back" : "front";
  } else if (hasInversion && maxRotSpeed > 30) {
    // Short segment but clearly inverted → fallback to direction unknown
    direction = "unknown";
  }

  const somersaultCount = roundQuarter(Math.abs(signedRot) / 360);
  const estimatedTwists = estimateTwists(widths);
  const shape = estimateShape(maxRotSpeed, avgInvAngle);

  const seg: Omit<SkillSegment, "estimatedName"> = {
    startFrame: segFrames[0].frameIndex,
    endFrame: segFrames[segFrames.length - 1].frameIndex,
    peakFrame: peakFrame.frameIndex,
    startTime: segFrames[0].timestamp,
    endTime: segFrames[segFrames.length - 1].timestamp,
    durationSec: segFrames[segFrames.length - 1].timestamp - segFrames[0].timestamp,
    totalRotationDeg: Math.round(totalAbsRot),
    signedRotationDeg: Math.round(signedRot),
    somersaultCount,
    direction,
    maxBodyAngle: Math.round(maxBodyAngle),
    estimatedTwists: Math.round(estimatedTwists * 2) / 2,
    hasInversion,
    shape,
    frameIndices: segFrames.map((f) => f.frameIndex),
    poseConfidence: segFrames.length > 0 ? confSum / segFrames.length : 0,
  };

  return { ...seg, estimatedName: buildEstimatedName(seg) };
}
