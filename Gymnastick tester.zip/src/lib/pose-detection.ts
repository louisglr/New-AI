// Pose detection utilities using MediaPipe
import { PoseLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";

let poseLandmarker: PoseLandmarker | null = null;

export interface PoseData {
  landmarks: Array<{ x: number; y: number; z: number; visibility: number }>;
  worldLandmarks: Array<{ x: number; y: number; z: number; visibility: number }>;
}

export interface FlipAnalysis {
  isInverted: boolean;
  bodyAngle: number; // degrees from vertical, 0..180
  signedBodyAngle: number; // -180..180, signed for rotation tracking
  shoulderWidth: number; // visual shoulder distance (normalized) - low = twisted side-on
  feetAboveHips: boolean;
  feetAboveShoulders: boolean;
  handsNearGround: boolean; // wrists near floor level — strong cue for handspring/cartwheel
  handsBelowHips: boolean; // wrists clearly below hips (inverted hand support)
  rotationSpeed: number; // degrees per frame
  confidence: number;
  phase: "takeoff" | "rotation" | "landing" | "none";
}

export async function initializePoseDetection() {
  if (poseLandmarker) return poseLandmarker;

  const vision = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm"
  );

  poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
    baseOptions: {
      modelAssetPath:
        "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task",
      delegate: "GPU",
    },
    runningMode: "IMAGE",
    numPoses: 1,
    minPoseDetectionConfidence: 0.5,
    minPosePresenceConfidence: 0.5,
    minTrackingConfidence: 0.5,
  });

  return poseLandmarker;
}

export async function detectPose(imageData: HTMLCanvasElement | HTMLImageElement): Promise<PoseData | null> {
  if (!poseLandmarker) {
    await initializePoseDetection();
  }

  if (!poseLandmarker) return null;

  const result = poseLandmarker.detect(imageData);

  if (!result.landmarks || result.landmarks.length === 0) {
    return null;
  }

  return {
    landmarks: result.landmarks[0].map((lm) => ({
      x: lm.x,
      y: lm.y,
      z: lm.z,
      visibility: lm.visibility ?? 0,
    })),
    worldLandmarks: result.worldLandmarks?.[0]?.map((lm) => ({
      x: lm.x,
      y: lm.y,
      z: lm.z,
      visibility: lm.visibility ?? 0,
    })) ?? [],
  };
}

// Analyze if a flip is occurring based on pose landmarks
export function analyzeFlip(
  currentPose: PoseData | null,
  previousPose: PoseData | null
): FlipAnalysis {
  if (!currentPose || !currentPose.landmarks || currentPose.landmarks.length < 33) {
    return {
      isInverted: false,
      bodyAngle: 0,
      signedBodyAngle: 0,
      shoulderWidth: 0,
      feetAboveHips: false,
      feetAboveShoulders: false,
      handsNearGround: false,
      handsBelowHips: false,
      rotationSpeed: 0,
      confidence: 0,
      phase: "none",
    };
  }

  const landmarks = currentPose.landmarks;

  // Key landmarks for flip detection
  const nose = landmarks[0];
  const leftShoulder = landmarks[11];
  const rightShoulder = landmarks[12];
  const leftWrist = landmarks[15];
  const rightWrist = landmarks[16];
  const leftHip = landmarks[23];
  const rightHip = landmarks[24];
  const leftAnkle = landmarks[27];
  const rightAnkle = landmarks[28];

  // Calculate center points
  const shoulderCenter = {
    x: (leftShoulder.x + rightShoulder.x) / 2,
    y: (leftShoulder.y + rightShoulder.y) / 2,
  };

  const hipCenter = {
    x: (leftHip.x + rightHip.x) / 2,
    y: (leftHip.y + rightHip.y) / 2,
  };

  const ankleCenter = {
    x: (leftAnkle.x + rightAnkle.x) / 2,
    y: (leftAnkle.y + rightAnkle.y) / 2,
  };

  // Signed body angle: angle of shoulder->hip vector measured from "down" axis (+Y in image coords)
  // Range: -180..180. 0 = upright (head up), ±180 = fully inverted.
  // atan2(x, y) gives angle where 0 = pointing down, +π/2 = pointing right, etc.
  const dx = hipCenter.x - shoulderCenter.x;
  const dy = hipCenter.y - shoulderCenter.y;
  const signedBodyAngle = Math.atan2(dx, dy) * (180 / Math.PI); // -180..180
  const bodyAngle = Math.abs(signedBodyAngle); // 0..180

  // Visual shoulder width — useful for twist detection.
  // When the body twists ~90° about its long axis, the shoulder line appears short in 2D.
  const shoulderWidth = Math.hypot(
    rightShoulder.x - leftShoulder.x,
    rightShoulder.y - leftShoulder.y
  );

  // Check if inverted (head below hips or extreme angle)
  const isInverted = nose.y > hipCenter.y || bodyAngle > 135;

  // Airborne indicators
  const feetAboveHips = ankleCenter.y < hipCenter.y;
  const feetAboveShoulders = ankleCenter.y < shoulderCenter.y;

  // Hand-contact heuristics (crucial for distinguishing handspring/cartwheel/round-off
  // from non-hand-supported flips). MediaPipe y is normalized 0..1, larger = further down.
  const wristY = (leftWrist.y + rightWrist.y) / 2;
  const ankleY = (leftAnkle.y + rightAnkle.y) / 2;
  // hands "near ground" = wrists within 10% normalized-y of the lowest body point (ankles or hips)
  const groundY = Math.max(ankleY, hipCenter.y);
  const handsNearGround = wristY > groundY - 0.08;
  const handsBelowHips = wristY > hipCenter.y + 0.05;

  // Calculate rotation speed if we have previous frame (uses signed angle, handles wrap-around)
  let rotationSpeed = 0;
  if (previousPose && previousPose.landmarks && previousPose.landmarks.length >= 33) {
    const prevLandmarks = previousPose.landmarks;
    const pls = prevLandmarks[11];
    const prs = prevLandmarks[12];
    const plh = prevLandmarks[23];
    const prh = prevLandmarks[24];

    const prevShoulderCenter = { x: (pls.x + prs.x) / 2, y: (pls.y + prs.y) / 2 };
    const prevHipCenter = { x: (plh.x + prh.x) / 2, y: (plh.y + prh.y) / 2 };
    const prevSigned =
      Math.atan2(
        prevHipCenter.x - prevShoulderCenter.x,
        prevHipCenter.y - prevShoulderCenter.y
      ) *
      (180 / Math.PI);

    // Shortest signed delta in -180..180
    let delta = signedBodyAngle - prevSigned;
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;
    rotationSpeed = Math.abs(delta);
  }

  // Determine flip phase
  let phase: "takeoff" | "rotation" | "landing" | "none" = "none";
  let confidence = 0;

  if (isInverted || feetAboveShoulders) {
    phase = "rotation";
    confidence = 0.9;
  } else if (bodyAngle > 45 && bodyAngle < 90 && rotationSpeed > 10) {
    phase = "takeoff";
    confidence = 0.7;
  } else if (bodyAngle > 30 && rotationSpeed > 5) {
    phase = "landing";
    confidence = 0.6;
  } else if (feetAboveHips && bodyAngle > 25) {
    phase = "takeoff";
    confidence = 0.55;
  }

  return {
    isInverted,
    bodyAngle,
    signedBodyAngle,
    shoulderWidth,
    feetAboveHips,
    feetAboveShoulders,
    handsNearGround,
    handsBelowHips,
    rotationSpeed,
    confidence,
    phase,
  };
}

// Draw pose landmarks on canvas for visualization
export function drawPose(
  canvas: HTMLCanvasElement,
  poseData: PoseData | null,
  flipAnalysis: FlipAnalysis
): void {
  if (!poseData || !poseData.landmarks) return;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const landmarks = poseData.landmarks;
  const width = canvas.width;
  const height = canvas.height;

  // Choose color based on flip detection
  const color = flipAnalysis.phase === "rotation" ? "#ff0000" : 
                flipAnalysis.phase === "takeoff" ? "#ff6600" :
                flipAnalysis.phase === "landing" ? "#ffcc00" : "#00ff00";

  // Draw connections
  const connections = [
    [11, 12], [11, 13], [13, 15], [12, 14], [14, 16], // arms
    [11, 23], [12, 24], [23, 24], // torso
    [23, 25], [25, 27], [24, 26], [26, 28], // legs
    [0, 11], [0, 12], // neck
  ];

  ctx.strokeStyle = color;
  ctx.lineWidth = 3;

  connections.forEach(([start, end]) => {
    const startLm = landmarks[start];
    const endLm = landmarks[end];
    if (startLm && endLm && startLm.visibility > 0.5 && endLm.visibility > 0.5) {
      ctx.beginPath();
      ctx.moveTo(startLm.x * width, startLm.y * height);
      ctx.lineTo(endLm.x * width, endLm.y * height);
      ctx.stroke();
    }
  });

  // Draw landmarks
  ctx.fillStyle = color;
  landmarks.forEach((lm, i) => {
    if (lm.visibility > 0.5) {
      ctx.beginPath();
      ctx.arc(lm.x * width, lm.y * height, 5, 0, 2 * Math.PI);
      ctx.fill();
    }
  });

  // Draw flip phase label
  if (flipAnalysis.phase !== "none") {
    ctx.fillStyle = color;
    ctx.font = "bold 20px Arial";
    ctx.fillText(
      `${flipAnalysis.phase.toUpperCase()} (${Math.round(flipAnalysis.bodyAngle)}°)`,
      10,
      30
    );
  }
}
