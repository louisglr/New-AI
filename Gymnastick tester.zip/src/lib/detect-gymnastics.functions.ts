import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  frames: z.array(z.string().startsWith("data:image/")).min(1).max(16),
});

export type Verdict = {
  isGymnastics: boolean;
  confidence: number;
  disciplines: string[];
  tricks: { name: string; confidence: number; description: string }[];
  hasTrick: boolean;
  reasoning: string;
};

export const detectGymnastics = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<Verdict> => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are an expert acrobatics & sports video analyst. You will see many frames sampled in strict chronological order from a single short video. The frames are numbered implicitly by position (first = earliest, last = latest).

CRITICAL RULES FOR TRICK DETECTION:
- Acrobatic tricks (flips, somersaults, twists) take only ~0.4–0.8s. They WILL appear in only 1–3 frames out of the batch. Do NOT dismiss a trick just because most frames show a person standing, walking, or landing.
- A trick IS present if ANY single frame shows clear evidence of inversion or airborne rotation:
  • head clearly lower than hips, or body fully upside-down
  • body tucked/piked in mid-air with both feet off the ground
  • horizontal or diagonal body orientation while airborne
  • feet above head level
- Use sequence reasoning: if early frames show a person standing/running and later frames show them standing again, BUT an intermediate frame shows them inverted or airborne in a tucked/piked position → that is a flip/somersault. Direction (forward vs backward) is inferred from the take-off and landing orientation.
- A "warm-up" / "preparation" verdict is only correct if NO frame shows inversion, airborne tuck/pike, or clearly non-vertical mid-air body.
- When unsure between "no trick" and "trick", prefer "trick" if at least one frame shows the body inverted or airborne in a non-vertical pose, and explicitly cite which frame index (1-based) is the evidence.

Tasks:
1. Decide whether the video shows GYMNASTICS content (artistic, rhythmic, trampoline, tumbling, acrobatic gymnastics, balance beam, uneven bars, pommel horse, rings, vault, floor exercise). Cheerleading stunts and competitive diving are NOT gymnastics. Parkour/freerunning/tricking is NOT gymnastics but CAN contain tricks.
2. Detect any acrobatic TRICK performed in the video. Vocabulary to use:
   - back flip / back somersault / back tuck / back layout / back pike
   - front flip / front somersault / front tuck / front layout / front pike
   - side flip / aerial / cartwheel / round-off / handspring (front or back)
   - full twist / 360 / 540 / 720 (vertical-axis rotation)
   - combinations (e.g. "back full-twisting layout", "double back tuck")
3. Scan EVERY frame for inversion or airborne rotation before concluding "no trick".

Return ONLY a JSON object with this exact shape:
{
  "isGymnastics": boolean,
  "confidence": number 0..1,
  "disciplines": string[],
  "hasTrick": boolean,
  "tricks": [
    { "name": "short trick name", "confidence": number 0..1, "description": "cite 1-based frame index(es) where rotation/inversion is visible and what you see" }
  ],
  "reasoning": "one short sentence summarizing your decision; if you say 'no trick', explicitly state that NO frame shows inversion or airborne rotation"
}

If no trick is detected, return "hasTrick": false and "tricks": [].`;

    const userContent: Array<
      { type: "text"; text: string } | { type: "image_url"; image_url: { url: string } }
    > = [
      {
        type: "text",
        text: `Analyze these ${data.frames.length} frames (in chronological order) and classify the video plus any acrobatic trick performed.`,
      },
      ...data.frames.map((f) => ({ type: "image_url" as const, image_url: { url: f } })),
    ];

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-pro",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      if (res.status === 429) throw new Error("Rate limit reached. Please try again shortly.");
      if (res.status === 402) throw new Error("AI credits exhausted. Add credits to continue.");
      throw new Error(`AI gateway error (${res.status}): ${text}`);
    }

    const json = (await res.json()) as {
      choices: Array<{ message: { content: string } }>;
    };
    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: Partial<Verdict>;
    try {
      parsed = JSON.parse(raw) as Partial<Verdict>;
    } catch {
      throw new Error("AI returned non-JSON response");
    }

    const tricks = Array.isArray(parsed.tricks)
      ? parsed.tricks
          .filter((t): t is { name: string; confidence: number; description: string } =>
            Boolean(t && typeof t.name === "string"),
          )
          .map((t) => ({
            name: t.name,
            confidence: typeof t.confidence === "number" ? t.confidence : 0,
            description: typeof t.description === "string" ? t.description : "",
          }))
      : [];

    return {
      isGymnastics: Boolean(parsed.isGymnastics),
      confidence: typeof parsed.confidence === "number" ? parsed.confidence : 0,
      disciplines: Array.isArray(parsed.disciplines) ? parsed.disciplines : [],
      hasTrick: typeof parsed.hasTrick === "boolean" ? parsed.hasTrick : tricks.length > 0,
      tricks,
      reasoning: typeof parsed.reasoning === "string" ? parsed.reasoning : "",
    };
  });
